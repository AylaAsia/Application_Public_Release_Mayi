package cn.antsnest.shop;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ayla.aylahome.api.CommonApi;
import com.ayla.aylahome.ui.AdvancedFunctionActivity;
import com.ayla.aylahome.ui.DeviceAddCategoryActivity;
import com.ayla.aylahome.ui.other.FragmentContainerActivity;
import com.ayla.base.bean.DeviceListBean;
import com.ayla.base.bean.UserInfo;
import com.ayla.base.common.AppData;
import com.ayla.base.common.CommonUtils;
import com.ayla.base.common.Constant;
import com.ayla.base.common.Keys;
import com.ayla.base.data.net.RetrofitFactory;
import com.ayla.base.data.protocol.BaseResp;
import com.ayla.base.ext.CommonExtKt;
import com.ayla.base.rx.BaseException;
import com.ayla.base.rx.BaseObserver;
import com.ayla.base.ui.activity.WebViewActivity;
import com.ayla.user.bean.RoomBean;
import com.ayla.user.ui.RoomManageActivity;
import com.blankj.utilcode.util.GsonUtils;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.WritableArray;
import com.facebook.react.bridge.WritableMap;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.Map;


/**
 * @ClassName:      AylaAndroid
 * @Description:    RN与艾拉智家Android通信模块
 * @Author:         vi1zen
 * @CreateDate:     2021/1/21 16:58
 */
public class AylaAndroid extends ReactContextBaseJavaModule {

    private static final String TAG = "AylaAndroid";

    private CommonApi api = RetrofitFactory.Companion.getInstance().create(CommonApi.class);

    public AylaAndroid(@Nullable ReactApplicationContext reactContext) {
        super(reactContext);
        initParams();
    }

    @NonNull
    @Override
    public String getName() {
        return "AylaAndroid";
    }

    private void initParams(){
        long roomId = AppData.INSTANCE.getSpUtils().getLong(Keys.HOME_ID,-1L);
        if(roomId != -1L){
            AppData.INSTANCE.setRoomId(String.valueOf(roomId));
        }
    }


    /**
     * 用户授权登录
     * @param accessToken       accessToken
     * @param successCallback   成功回调
     * @param errorCallback     成功回调
     */
    @ReactMethod
    public void login(String accessToken, Callback successCallback, Callback errorCallback){
        Log.d(TAG,"invoke login,accessToken = " + accessToken);
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("accessToken",accessToken);
        CommonExtKt.request(api.tokenLoginForAnt(CommonUtils.json2Body(jsonObject)),new BaseObserver<BaseResp<UserInfo>>(){
            @Override
            public void onNext(BaseResp<UserInfo> userInfoBaseResp) {
                super.onNext(userInfoBaseResp);
                UserInfo userInfo = userInfoBaseResp.getData();
                AppData.INSTANCE.getSpUtils().put(Constant.KEY_SP_TOKEN,userInfo.getAuthToken());
                AppData.INSTANCE.getSpUtils().put(Constant.KEY_SP_REFRESH_TOKEN,userInfo.getRefreshToken());
                if(!userInfo.getHomeList().isEmpty()){
                    long roomId = userInfo.getHomeList().get(0).getId();
                    AppData.INSTANCE.getSpUtils().put(Keys.HOME_ID,roomId);
                    AppData.INSTANCE.setRoomId(String.valueOf(roomId));
                }
                successCallback.invoke();
            }

            @Override
            public void onError(@org.jetbrains.annotations.Nullable Throwable e) {
                if(e instanceof BaseException){
                    String msg = ((BaseException) e).getMsg();
                    int errorCode = ((BaseException) e).getCode();
                    Log.d(TAG,"login,error msg = " + msg + "errorCode = " + errorCode);
                    //判断token是否过期
                    if(errorCode == 121002){
                        errorCallback.invoke("121002");
                    }else {
                        errorCallback.invoke(msg);
                    }
                } else {
                    errorCallback.invoke("服务异常");
                }
            }
        });
    }

    /**
     * 退出登录
     */
    @ReactMethod
    public void logout(){
        Log.d(TAG,"invoke logout");
        AppData.INSTANCE.getSpUtils().put(Constant.KEY_SP_TOKEN,"");
        AppData.INSTANCE.getSpUtils().put(Constant.KEY_SP_REFRESH_TOKEN,"");
        AppData.INSTANCE.getSpUtils().put(Keys.HOME_ID,-1L);
        AppData.INSTANCE.setRoomId("");
    }

    /**
     * 判断是否已授权
     * @param callback          回调(true:已授权 false:未授权)
     */
    @ReactMethod
    public void isAuthorized(Callback callback){
        Log.d(TAG,"invoke isAuthorized");
        String aylaToken = AppData.INSTANCE.getSpUtils().getString(Constant.KEY_SP_TOKEN);
        boolean isAuthorized = !TextUtils.isEmpty(aylaToken);
        Log.d(TAG,"isAuthorized = " + isAuthorized);
        callback.invoke(isAuthorized);
    }

    /**
     * 跳转到品类中心
     */
    @ReactMethod
    public void toDeviceCategoryPage(){
        Log.d(TAG,"invoke toDeviceCategoryPage");
        Intent intent = new Intent(getReactApplicationContext(), DeviceAddCategoryActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getReactApplicationContext().startActivity(intent);
    }

    /**
     * 跳转到智控页
     */
    @ReactMethod
    public void toSmartControlPage(){
        Log.d(TAG,"invoke toSmartControlPage");
        Intent intent = new Intent(getReactApplicationContext(), FragmentContainerActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getReactApplicationContext().startActivity(intent);
    }

    /**
     * 跳转到房间管理页面
     */
    @ReactMethod
    public void toRoomManagePage(){
        Log.d(TAG,"invoke toRoomManagePage");
        Intent intent = new Intent(getReactApplicationContext(), RoomManageActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getReactApplicationContext().startActivity(intent);
    }

    /**
     * 获取房间列表
     * @param successCallback   成功回调
     * @param errorCallback     失败回调
     */
    @ReactMethod
    public void getRoomList(Callback successCallback, Callback errorCallback){
        Log.d(TAG,"invoke getRoomList");
        CommonExtKt.request(api.getExistRoom(),new BaseObserver<BaseResp<ArrayList<RoomBean>>>(){
            @Override
            public void onNext(BaseResp<ArrayList<RoomBean>> arrayListBaseResp) {
                super.onNext(arrayListBaseResp);
                WritableArray writableArray = Arguments.createArray();
                WritableMap defaultTabMap = Arguments.createMap();
                defaultTabMap.putString("id", "-1");
                defaultTabMap.putString("roomName", "全部");
                writableArray.pushMap(defaultTabMap);
                for (RoomBean bean : arrayListBaseResp.getData()) {
                    WritableMap writableMap = Arguments.createMap();
                    writableMap.putString("id", String.valueOf(bean.getId()));
                    writableMap.putString("roomName", bean.getRoomName());
                    writableArray.pushMap(writableMap);
                }
                successCallback.invoke(writableArray);
            }
            @Override
            public void onError(@org.jetbrains.annotations.Nullable Throwable e) {
                errorCallback.invoke(e instanceof BaseException ? ((BaseException) e).getMsg() : "服务异常");
            }
        });
    }

    /**
     * 获取设备列表
     * @param successCallback   成功回调
     * @param errorCallback     失败回调
     */
    @ReactMethod
    public void getDeviceList(String locationId, Callback successCallback, Callback errorCallback){
        Log.d(TAG,"invoke getDeviceList,locationId = " + locationId);
        try {
            long mLocationId = Long.parseLong(locationId);
            JsonObject body = new JsonObject();
            body.addProperty("roomId", AppData.INSTANCE.getRoomId());
            body.addProperty("pageNo", 1);
            body.addProperty("pageSize", 200);
            if(mLocationId != -1L){
                body.addProperty("locationId", mLocationId);
            }
            CommonExtKt.request(api.getHomeDeviceList(CommonUtils.json2Body(body)),new BaseObserver<BaseResp<DeviceListBean>>(){
                @Override
                public void onNext(BaseResp<DeviceListBean> deviceListBeanBaseResp) {
                    super.onNext(deviceListBeanBaseResp);
                    WritableArray writableArray = Arguments.createArray();
                    if(deviceListBeanBaseResp.getData().getDevices() == null){
                        successCallback.invoke(writableArray);
                        return;
                    }
                    if(mLocationId == -1L){
                        AppData.INSTANCE.setDevicesBean(deviceListBeanBaseResp.getData().getDevices());
                    }
                    for (DeviceListBean.DevicesBean bean : deviceListBeanBaseResp.getData().getDevices()) {
                        if(bean.getDeviceUseType() == 3){//过滤设备用途源设备
                            continue;
                        }
                        WritableMap writableMap = Arguments.createMap();
                        writableMap.putInt("cuId", bean.getCuId());
                        writableMap.putString("deviceId", bean.getDeviceId());
                        writableMap.putString("deviceName", bean.getDeviceName());
                        writableMap.putString("nickname", bean.getNickname());
                        writableMap.putString("deviceCategory",bean.getDeviceCategory());
                        writableMap.putString("deviceStatus",bean.getDeviceStatus());
                        writableMap.putString("pid",bean.getPid());
                        writableMap.putInt("connectTypeId",bean.getConnectTypeId());
                        writableMap.putInt("isNeedGateway",bean.getIsNeedGateway());
                        writableMap.putInt("productType",bean.getProductType());
                        writableMap.putString("iconUrl",bean.getIconUrl());
                        writableMap.putString("purposeName",bean.getPurposeName());
                        writableMap.putInt("hasH5",bean.getHasH5());
                        writableMap.putInt("isPurposeDevice",bean.getIsPurposeDevice());
                        writableMap.putInt("deviceUseType",bean.getDeviceUseType());
                        writableMap.putString("firmwareVersion",bean.getFirmwareVersion());
                        WritableMap metadataMap = Arguments.createMap();
                        for (Map.Entry<String, String> entry : bean.getMetadata().entrySet()) {
                            metadataMap.putString(entry.getKey(), entry.getValue());
                        }
                        writableMap.putMap("metadata",metadataMap);
                        writableArray.pushMap(writableMap);
                    }
                    successCallback.invoke(writableArray);
                }

                @Override
                public void onError(@org.jetbrains.annotations.Nullable Throwable e) {
                    errorCallback.invoke(e instanceof BaseException ? ((BaseException) e).getMsg() : "服务异常");
                }
            });
        } catch (NumberFormatException e) {
            e.printStackTrace();
            errorCallback.invoke(e.getLocalizedMessage());
        }
    }

    /**
     * 点击设备列表ITEM
     * @param itemJsonString    item数据
     * @param errorCallback     失败回调
     */
    @ReactMethod
    public void onClickDeviceListItem(String itemJsonString, Callback errorCallback){
        Log.d(TAG,"invoke onClickDeviceListItem");
        try {
            DeviceListBean.DevicesBean bean = GsonUtils.fromJson(itemJsonString, DeviceListBean.DevicesBean.class);
            if(bean.getHasH5() == 1){
                Intent intent = new Intent(getReactApplicationContext(),WebViewActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra(Keys.URL, com.ayla.base.BuildConfig.H5_URL);
                intent.putExtra(Keys.DATA,bean);
                getReactApplicationContext().startActivity(intent);
            }else{
                Intent intent = new Intent(getReactApplicationContext(), AdvancedFunctionActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra(Keys.URL, com.ayla.base.BuildConfig.H5_URL);
                intent.putExtra(Keys.DATA,bean);
                Bundle bundle = new Bundle();
                bundle.putSerializable("devicesBean",bean);
                intent.putExtras(bundle);
                getReactApplicationContext().startActivity(intent);
            }
        } catch (Exception e) {
            e.printStackTrace();
            errorCallback.invoke(e.getLocalizedMessage());
        }
    }
}
