/* eslint-disable react-native/no-inline-styles */
/* eslint-disable jsx-quotes */
/* eslint-disable quotes */
/* eslint-disable prettier/prettier */
/*
 * @description: 下单页面
 * @author: fanyang
 * @lastEditors: fanyang
 * @Date: 2020-06-16 15:44:10
 * @LastEditTime: 2020-12-23 15:10:29
 */
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Container, Content, Title, Left, Body, Right, Button, Icon, Item, Input } from 'native-base';

/**Redux Actions */
import { connect } from 'react-redux';
/**Router */
import { Actions } from 'react-native-router-flux';

import { globalData,storage } from '../../utils';

import baseStyle from '../../assets/style/base';

import config from '../../config';
import { setAccount, setStatus } from '../../store/actions'

import AsyncStorage  from '@react-native-community/async-storage';

import AylaAndroid from "../../utils/AylaAndroid";
import ScrollableTabView, { ScrollableTabBar } from 'react-native-scrollable-tab-view';
import ActionButton from '@logvinme/react-native-action-button';
import AylaAuth from './AylaAuth';

import {
  View,
  Text,
  TouchableOpacity,
  ToastAndroid,
  StyleSheet,
  Image,
  StatusBar,
  FlatList,
  ImageBackground,
  Platform,
  AppState,
  DeviceEventEmitter,
} from 'react-native';


const defaultTabs = [{id:'-1',roomName:"全部"}];

class AylaHome extends Component {

  constructor(props){
    super(props);
    this.state = {
      isLogin:false,
      isAylaAuthSuccess:false,
      appState:AppState.currentState,
      tabs:defaultTabs,
    };
    console.log("init >>>>>>>>>>>>>>>>> ",this.state);
  }

  async componentWillMount () {
    console.log("======================componentWillMount");
    /**获取用户登录信息 */
    try {
      await this._getAccount();
    } catch (err) {
      console.log("componentWillMount _getAccount error",err);
    }
    this.didFocusListener = this.props.navigation.addListener('didFocus',async (obj) => {
      console.log('Smart focus>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>');
      try {
         this._getAccount();
      } catch (err) {
        console.log("componentWillMount _getAccount error",err);
      }
    });
  }

  /**获取本地用户信息 */
  async _getAccount() {

    let account = {},
        key = config.storageKey.account;
    try {
        account = await storage.get(key) || "{}";
    } catch (err) {
        console.log('_getAccount storage account', account)
        this.setState({isLogin:false});
        return {};
    }

    /**设置用户信息 */
    account = typeof account === 'string' ? JSON.parse(account) : account;
    console.log('Smart | local account = ', account)
    if (account && account.id){
      AylaAndroid.isAuthorized((isAylaAuthSuccess) => {
        this.setState({
          isAylaAuthSuccess:isAylaAuthSuccess,
          appState:AppState.currentState,
          // tabs:defaultTabs,
          account:account,
          isLogin:true,
        });
        // this.state ={
        //   isAylaAuthSuccess:isAylaAuthSuccess,
        //   appState:AppState.currentState,
        //   tabs:defaultTabs,
        //   account:account,
        //   isLogin:true,
        // };
        console.log("account >>>>>>>>>>>>>>>>>>",this.state);
        if (isAylaAuthSuccess){
          this._getRoomList();
        }
      });
    } else {
      console.log("用户未登录！！！！！！！！！！！！！！！！！！！！！！！！！！");
      AylaAndroid.logout();
      this.setState({
        isAylaAuthSuccess:false,
        appState:AppState.currentState,
        tabs:defaultTabs,
        account:account,
        isLogin:false,
      });
    }
}

  /**
   * 跳转到设备品类中心
   */
  toDeviceCategoryPage = () => {
    console.log("正在跳转到设备品类中心");
    this.doNextIfLogin(AylaAndroid.toDeviceCategoryPage);
  };

  /**
   * 跳转到智控页面
   */
  toSmartControlPage = () => {
    console.log("正在跳转到智控页面");
    this.doNextIfLogin(AylaAndroid.toSmartControlPage);
  };

  /**
   * 跳转到房间管理页面
   */
  toRoomManagePage = () => {
    console.log("正在跳转到管理页面");
    this.doNextIfLogin(AylaAndroid.toRoomManagePage);
  };

  /**
   * 判断是否登录
   */
  doNextIfLogin = (doNext) => {
    if (this.state.isLogin){
      doNext();
    } else {
      ToastAndroid.show("请登录后重试",ToastAndroid.SHORT);
      console.log("请登录后重试>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
      Actions.Account();
    }
  };

  _getRoomList = () => {
    AylaAndroid.getRoomList((roomList) => {
      // console.log(roomList);
      this.setState({tabs:roomList});
    },(error) => {
      console.log(error);
    });
  }

  componentWillReceiveProps (nextProps) {
    console.log("AylaHome componentWillReceiveProps");
    // console.log(nextProps.userInfo);
    // let _isLogin = nextProps.userInfo.token != null && nextProps.userInfo.token !== "";
    // console.log("componentWillReceiveProps nextProps _isLogin = ",_isLogin);
    // this.setState({
    //   islogin:_isLogin,
    //   isAylaAuthSuccess:false,
    //   userInfo:nextProps.userInfo,
    // });
  }

  componentDidMount (){
    console.log("componentDidMount");
    //监听登录事件
    // this.listener = DeviceEventEmitter.addListener("login",(info) => {
    //   this.setState({
    //     isAylaAuthSuccess:false,
    //   });
    // });
    AppState.addEventListener('change',this._handleAppStateChange);
  }

  componentWillUnmount() {
    // this.listener.remove();
    this.didFocusListener.remove();
    AppState.removeEventListener('change', this._handleAppStateChange);
  }

  _handleAppStateChange = (nextAppState) => {
    if (this.state.appState.match(/inactive|background/) && nextAppState === 'active') {
      console.log('App has come to the foreground! = ',this.state);
      if(this.state.isLogin && this.state.isAylaAuthSuccess){
        this._getRoomList();
      }
    }
    this.state.appState = nextAppState;
    console.log(this.state);
  }

  /**
   * 接收艾拉智家授权登录结果
   */
  onAuthResult = (success) => {
    this.state.isAylaAuthSuccess = success;
    this.state.isLogin = success;
    console.log("onAuthResult success = ",success);
    console.log("onAuthResult",this.state);
    if(success){
      this._getRoomList();
    }else{
      this.setState({isLogin:false});
    }
  }

  _renderActionButton = () => {
    console.log("this.state.isLogin = ",this.state.isLogin);
    if (this.state.isLogin){
      return (
        <ActionButton buttonColor="#F39910" fixNativeFeedbackRadius={true} >
          <ActionButton.Item buttonColor='#56AAEE' useNativeFeedback={false} hideShadow='true' title="智能" onPress={this.toSmartControlPage}>
            <Image source={ require("../../assets/img/smart/ic_home.png") } style={styles.actionItem}/>
          </ActionButton.Item>
          <ActionButton.Item buttonColor='#3B63EA' useNativeFeedback={false} hideShadow='true' title="管理" onPress={this.toRoomManagePage}>
            <Image source={ require("../../assets/img/smart/ic_menu.png") } style={styles.actionItem}/>
          </ActionButton.Item>
        </ActionButton>
      );
    } else {
      return null;
    }
  };

  render(){
    console.log("isAylaAuthSuccess",this.state.isAylaAuthSuccess,"isLogin = ",this.state.isLogin);
    if (this.state.isLogin && !this.state.isAylaAuthSuccess) {
      return (
        <AylaAuth onAuthResult={this.onAuthResult.bind(this)} userInfo={this.state.account}/>
      );
    } else {
      if (Platform.OS === 'android'){
        return (
          <View style={styles.body}>
            <StatusBar backgroundColor='transparent' barStyle='light-content' translucent={true}/>
            <ImageBackground source={require('../../assets/img/smart/home_top.webp')} resizeMode='stretch'  style={styles.topBg}>
              <Text style={styles.tip}>欢迎回家</Text>
              <TouchableOpacity onPress={this.toDeviceCategoryPage} style={styles.addBtn}>
                <Image source={require('../../assets/img/smart/home_add.png')} resizeMode='stretch' style={{width:80,height:80}}/>
              </TouchableOpacity>
            </ImageBackground>
            <ScrollableTabView initialPage={0} renderTabBar={() => <ScrollableTabBar tabsContainerStyle={{justifyContent:'flex-start'}} style={styles.tabs}/>}
                style={styles.tabContainer}
                tabBarUnderlineStyle={{backgroundColor:'#F39910', height:1}}
                tabBarActiveTextColor='black'
                tabBarInactiveTextColor='gray'
                tabBarPosition='top'
                >
                {
                this.state.tabs.map((item, i) => {
                  return (
                      <DeviceListView tabLabel={item.roomName} key={i} locationId={item.id} doNextIfLogin={this.doNextIfLogin} isLogin={this.state.isLogin}/>
                  );})
                }
            </ScrollableTabView>
            {this._renderActionButton()}
          </View>
        );
      } else {
        return (
          <Text>IOS</Text>
        );
      }
    }
  }
}

const ITEM_HEIGHT = 80;

const _renderSeparator = (index,length) => {
  if (index !== length - 1) {
    return (
      <View style={{height:2,position:'absolute',bottom:0,left:0,right:0}}>
        <View style={{height:1,marginStart:40,marginEnd:40,backgroundColor:'#F4F6F7'}}/>
        <View style={{height:1,marginStart:40,marginEnd:40,backgroundColor:'#D9DDE5'}}/>
      </View>);
  }
  return null;
};

class MultiItem extends Component {

  _itemClick(itemData){
    // console.log("itemClick",JSON.stringify(itemData));
    this.props.doNextIfLogin(() => {
      AylaAndroid.onClickDeviceListItem(JSON.stringify(itemData),(errorMsg) => {
        ToastAndroid.show(errorMsg,ToastAndroid.SHORT);
      });
    });
  }

  render() {
    let item = this.props.item;
    let index = this.props.index;
    let length = this.props.length;
    let itemBgUri;
    let paddingTop = 0;
    let paddingBottom = 0;
    if (index === 0){
      if (length === 1){
        itemBgUri = require('../../assets/img/smart/home_item.png');
      } else {
        paddingTop = 5;
        itemBgUri = require('../../assets/img/smart/home_item_top.png');
      }
    } else if (index === length - 1){
      paddingBottom = 5;
      itemBgUri = require('../../assets/img/smart/home_item_bottom.png');
    } else {
      itemBgUri = require('../../assets/img/smart/home_item_center.png');
    }
    let deviceStatus = item.deviceStatus === "ONLINE" ? "在线" : "离线";
    let statusPoint = item.deviceStatus === "ONLINE" ? require('../../assets/img/smart/online_point.png') : require('../../assets/img/smart/offline_point.png');
    let name = item.nickname === "" ? item.deviceName : item.nickname;
    return (
      <TouchableOpacity activeOpacity={0.9} onPress={ this._itemClick.bind(this,item) }>
        <ImageBackground style={{position:'relative',height:ITEM_HEIGHT,width:'100%',paddingTop:paddingTop,paddingBottom:paddingBottom}} source={ itemBgUri } resizeMode='stretch'>
          <View style={styles.item}>
            <Image source={{uri: item.iconUrl}} style={styles.itemIcon}/>
            <Text style={styles.itemTitle} numberOfLines={1} ellipsizeMode={'tail'}>{name}</Text>
            <Image source={statusPoint} style={styles.statusPoint}/>
            <Text style={styles.statusText}>{deviceStatus}</Text>
          </View>
          {_renderSeparator(index,length)}
        </ImageBackground>
      </TouchableOpacity>
    );
  }
}

class DeviceListView extends Component {

  constructor(props){
    super(props);
    this.state = {
      locationId:this.props.locationId,
      page:1,
      refreshing:false,
      data:[],
    };
    console.log("locationId =", this.props.locationId);
    // this.props.doNextIfLogin(this.requestData);
  }

  componentDidMount () {
    console.log("DeviceListView componentDidMount");
    if(this.props.isLogin){
      this.requestData();
    }
  }

  componentWillReceiveProps () {
    console.log("DeviceListView componentWillReceiveProps");
    if(this.props.isLogin){
      this.requestData();
    }
  }

  _onRefresh = ()=> {
    console.log("_onRefresh......................................");
    this.setState({
      page:1,
      refreshing:true,
      // data:[],
    },()=> {
      this.props.doNextIfLogin(this.requestData);
     });
  };

  requestData = () => {
    AylaAndroid.getDeviceList(this.state.locationId,
      (deviceList) => {
        // console.log(deviceList);
        this.setState({
          page:1,
          refreshing:false,
          data:deviceList,
        });
      },
      (error) => {
        // console.log(error);
        this.setState({
          page:1,
          refreshing:false,
          data:[],
        });
      });
  };

  renderItem = ({item,index}) => {
    return <MultiItem item={item} index={this.state.data.indexOf(item)} length={this.state.data.length} doNextIfLogin={this.props.doNextIfLogin}/>;
  };

  _toDeviceCategoryPage = () => {
    this.props.doNextIfLogin(AylaAndroid.toDeviceCategoryPage);
  };

  emptyView = () => {
    return (
      <View style={{justifyContent:'center',height:'100%',alignItems:'center'}}>
        <Image source={ require('../../assets/img/smart/device_empty.webp') } resizeMode='center' style={{height:150,width:260}}/>
        <Text style={{color:'#ADB2C0',fontSize:16,alignSelf:'center'}}>暂无设备请添加</Text>
        <TouchableOpacity onPress={this._toDeviceCategoryPage}>
          <Image source={ require('../../assets/img/smart/add_button.png') } style={{width:210,height:85,alignSelf:'center',marginTop:15}}/>
        </TouchableOpacity>
      </View>
    );
  };


  render () {
    return (
      <FlatList
        style={{marginTop:5}}
        showsVerticalScrollIndicator = {false}
        showsHorizontalScrollIndicator = {false}
        contentContainerStyle={{ flexGrow: 1 }}
        data={this.state.data}
        renderItem={this.renderItem}
        keyExtractor={item => item.deviceId}
        getItemLayout = { (item,index) => ({length:ITEM_HEIGHT,offset:ITEM_HEIGHT * index,index})}
        ListEmptyComponent = {this.emptyView}
        onRefresh={this._onRefresh}
        refreshing={this.state.refreshing}
      />
    );
  }
}

const styles = StyleSheet.create({
  body: {
    backgroundColor: "#EAEDF0",
    flex:1,
  },
  topBg:{
    width:'100%',
    height:260,
    justifyContent:'center',
    flexDirection:'column',
  },
  tip:{
    fontSize:24,
    fontWeight:'bold',
    color:'white',
    marginStart:30,
    marginBottom:80,
    letterSpacing:2,
  },
  addBtn:{
    width:80,
    height:80,
    position:'absolute',
    alignSelf:'flex-end',
    bottom:130,
    right:10,
  },
  tabContainer:{
    bottom:10,
    marginTop:-50,
  },
  tabs:{
    height:50,
    borderWidth:0,
    marginStart:25,
    marginEnd:25,
  },
  itemBg: {
    height:ITEM_HEIGHT,
    width:'100%',
    flexDirection:'column',
  },
  item:{
    flexDirection:'row',
    height:ITEM_HEIGHT,
    marginStart:40,
  },
  itemIcon:{
    width:30,
    height:30,
    alignSelf:'center',
  },
  itemTitle:{
    alignSelf:'center',
    marginStart:5,
    flex:1,
    fontSize:14,
    color:'#3C3C3C',
  },
  statusPoint:{
    width:8,
    height:8,
    alignSelf:'center',
    marginTop:2,
  },
  statusText:{
    alignSelf:'center',
    marginStart:3,
    marginEnd:40,
    color:'#8A8B8D',
  },
  actionItem:{
    width:20,
    height:20,
  },
});

export default connect()(AylaHome);
