/* eslint-disable quotes */
/* eslint-disable jsx-quotes */
/* eslint-disable prettier/prettier */
/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { Component } from 'react';
import AylaAndroid from '../../utils/AylaAndroid';
import config from '../../config';
import { storage } from '../../utils';


import {
  View,
  Text,
  TouchableOpacity,
  ToastAndroid,
  StyleSheet,
  Image,
  StatusBar,
} from 'react-native';

class AylaAuth extends Component {

  _toAylaLogin(){
    console.log("登录艾拉智家账号中...token = ",this.props);
    AylaAndroid.login(this.props.userInfo.token,() => {
      console.log("登录艾拉智家成功");
      this.props.onAuthResult(true);
    },async (errorMsg) => {
      console.log("登录艾拉智家失败",errorMsg);
      if(errorMsg === "121002"){
        ToastAndroid.show("登录超时",ToastAndroid.SHORT);
        //token过期，清除艾拉智家和蚂蚁乐居登录状态
        AylaAndroid.logout();
        //清除蚂蚁乐居登录信息
        try {
           await storage.remove(config.storageKey.account);
        } catch (err) {
          console.log("remove account error",err);
        }
        this.props.onAuthResult(false);
      }else{
        ToastAndroid.show(errorMsg,ToastAndroid.SHORT);
      }
    });
  }

  render(){
    // console.log("uuuuuuuuuuuuuuuuuuuuuuuuu",this.props);
    let avatar =   this.props.userInfo.avatar ? { uri: this.props.userInfo.avatar } : (require('../../assets/img/account/avatar.png'))
    let phone =  this.props.userInfo.phone ? this.props.userInfo.phone :  ''
    return (
      <View style={styles.body}>
        <StatusBar backgroundColor='transparent' translucent={true} barStyle='dark-content'/>
        <Image source={require('../../assets/img/smart/auth_background.png')} style={styles.authBg} resizeMode='stretch'/>
        <Image source={avatar} resizeMode='cover'  style={styles.avatar}/>
        <Text style={styles.phoneNum}>{phone}</Text>
        <Text style={styles.tips}>智能家居相关功能登录后方可使用</Text>
        <Text style={styles.tip}>使用蚂蚁乐居账号授权并登录</Text>
        <TouchableOpacity activeOpacity={0.6} style={styles.btnContainer} onPress={this._toAylaLogin.bind(this)}>
          <View >
            <Text style={styles.btnText}>确认登录</Text>
          </View>
        </TouchableOpacity>
      </View>
  );
  }
}

const styles = StyleSheet.create({
  body: {
    backgroundColor: 'white',
    flex:1,
    justifyContent:'center',
    paddingBottom:80,
  },
  authBg:{
    width:'100%',
    height:280,
    position:'absolute',
    top:0,
  },
  avatar:{
    alignSelf:'center',
    borderColor:'#F39910',
    borderWidth:4,
    borderRadius:55,
    height:110,
    width:110,
  },
  phoneNum:{
    alignSelf:'center',
    fontWeight:'bold',
    color:'#333333',
    fontSize:30,
    marginTop:20,
  },
  tips:{
    marginTop:10,
    height:30,
    fontSize:16,
    color:'#ADADAD',
    alignSelf:'center',
  },
  tip:{
    height:30,
    fontSize:16,
    color:'#ADADAD',
    alignSelf:'center',
  },
  btnContainer:{
    width:'60%',
    height: 55,
    borderRadius: 30,
    marginTop:24,
    backgroundColor: '#F39910',
    justifyContent: 'center',
    alignSelf:'center',
  },
  btnText:{
    textAlign:'center',
    alignItems:'center',
    alignSelf:'center',
    fontSize:18,
    color:'white',
  },
});

export default AylaAuth;
